#ifndef ADD_H
#define ADD_H

#include <QWidget>
#include<QDate>
#include<QCloseEvent>
namespace Ui {
class add;
}

class add : public QWidget
{
    Q_OBJECT
protected:
    void closeEvent(QCloseEvent *event);
public:
    explicit add(QWidget *parent = nullptr);
    ~add();

private slots:
    void on_pushButton_2_clicked();

    void on_quxiao_clicked();

private:
    Ui::add *ui;
signals:
    void sendData(QString,QString,int,QDate,int,int);
    //void getzhuti(QString zhuti);
    //void getneirong(QString neirong);
    //void getyouxianji(int youxianji);
    //void getshijian(QDate shijian);
private slots: // 添加任务操作的槽函数声明
    void receiveData2(QString zhuti,QString Neirong,int youxianji,QDate shijian,int row,int finished);
    void on_pushButton_2_pressed();
    void on_quxiao_pressed();
};

#endif // ADD_H
///////!!!具体内容详见.cpp
