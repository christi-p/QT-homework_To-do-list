#include "add.h"
#include "ui_add.h"
#include<QDate>
int correct=-100;
int done=0;
add::add(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::add)
{
    ui->setupUi(this);
    //界面设计
    ui->zhuti->setPlaceholderText("请输入主题");
    ui->neirong->setPlaceholderText("请输入内容");
    ui->zhuti->setStyleSheet("font: 25 14pt '楷体';" //字体
                             "color: rgb(31,31,31);"		//字体颜色
                             "padding-left:20px;"       //内边距-字体缩进
                             "background-color: rgb(255, 255, 255);" //背景颜色
                             "border:2px solid rgb(160, 238, 225);border-radius:10px;");//边框粗细-颜色-圆角设置
    ui->neirong->setStyleSheet("font: 25 14pt '楷体';" //字体
                             "color: rgb(31,31,31);"		//字体颜色
                             "padding-left:20px;"       //内边距-字体缩进
                             "background-color: rgb(255, 255, 255);" //背景颜色
                             "border:2px solid rgb(160,238,225);border-radius:10px;");//边框粗细-颜色-圆角设置
    ui->date->setStyleSheet("background-color: rgb(255, 255, 255);"); //背景颜色;
    ui->priority->setStyleSheet("background-color: rgb(255, 255, 255);"); //背景颜色
    ui->textBrowser->setStyleSheet("background-color: rgb(240,255,240);" //背景颜色
                                   "border:1px solid rgb(160,238,225);border-radius:2px;");
    ui->textBrowser_2->setStyleSheet("background-color: rgb(240,255,240);" //背景颜色
                                   "border:1px solid rgb(160,238,225);border-radius:2px;");
    ui->textBrowser_3->setStyleSheet("background-color: rgb(240,255,240);" //背景颜色
                                   "border:1px solid rgb(160,238,225);border-radius:2px;");
    ui->textBrowser_4->setStyleSheet("background-color: rgb(240,255,240);" //背景颜色
                                     "border:1px solid rgb(160,238,225);border-radius:2px;");
    ui->pushButton_2->setStyleSheet("background-color: rgb(255,255,240);" //背景颜色
                                    "border:1px solid rgb(255,215,0);border-radius:2px;");//pressed);
    ui->quxiao->setStyleSheet("background-color: rgb(255,255,240);" //背景颜色
                                   "border:1px solid rgb(255,215,0);border-radius:2px;");
    this->setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 252, 153, 255), stop:1 rgba(227, 237, 205, 255));");
    ui->date->setMinimumDate(QDate::currentDate());
    ui->date->setMaximumDate(QDate::currentDate().addDays(365*3));
    ui->date->setCalendarPopup(free);
}

add::~add()
{
    correct=-100;
    delete ui;
}

void add::on_pushButton_2_clicked()//向主窗口发送信息
{

    sendData(ui->zhuti->toPlainText(),ui->neirong->toPlainText(),ui->priority->value(),ui->date->date(),correct,done);
    done=0;
    correct=-100;
    //emit getzhuti(ui->zhuti->toPlainText());
    //emit getneirong(ui->neirong->toPlainText());
    //emit getyouxianji(ui->priority->value());
    //emit getshijian(ui->date->date());
    ui->zhuti->clear();
    ui->neirong->clear();
    ui->priority->clear();
    ui->date->clear();
    this->~add();

}
void add::receiveData2(QString zhuti,QString Neirong,int youxianji,QDate shijian,int row,int finished){//接收主窗口的信息
    ui->zhuti->setPlainText(zhuti);
    ui->neirong->setPlainText(Neirong);
    ui->priority->setValue(youxianji);
    ui->date->setDate(shijian);
    correct=row;
    done=finished;

}
void add::closeEvent(QCloseEvent *event){
    correct=-100;
}
void add::on_quxiao_clicked()//取消按钮
{
    ui->zhuti->clear();
    ui->neirong->clear();
    ui->priority->clear();
    ui->date->clear();
    this->~add();
}

//以下是按钮被选中时的变化效果
void add::on_pushButton_2_pressed()
{
    ui->pushButton_2->setStyleSheet(
        "background-color: rgba(209,186,116,150);");//pressed);)
}




void add::on_quxiao_pressed()
{
    ui->quxiao->setStyleSheet(
        "background-color: rgba(209,186,116,150);");//pressed);)
}

