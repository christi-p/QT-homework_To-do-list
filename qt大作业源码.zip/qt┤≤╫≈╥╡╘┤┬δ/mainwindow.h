#ifndef MAINWINDOW_H//预处理器宏，避免头文件被重复包含（多重包含保护）
#define MAINWINDOW_H//防止在同一个编译单元中多次定义相同的类或变量

#include <QMainWindow>//是QT中用于创建主窗口的基类
#include <QListWidget>
#include <QLineEdit>
#include <QPushButton>
#include<QStringListModel>
#include<QTableWidgetItem>
#include"add.h"
#include<QCloseEvent>

QT_BEGIN_NAMESPACE//宏，包裹Qt相关的命名空间代码，有助于解决名称冲突问题，保持代码的清晰和模块化
namespace Ui {
class MainWindow;
}//由Qt User Interface Compiler自动生成的类，用于管理由Qt设计的ui界面的widgets和布局
//在实际运行中负责加载和设置ui文件定义的界面元素
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT//宏必须，对于使用Qt信号与槽机制的类
protected:
    void closeEvent(QCloseEvent *event);
public:
    MainWindow(QWidget *parent = nullptr);//构造函数接受一个指向父窗口的指针，默认没有
    ~MainWindow();//析构函数为虚函数，用于清理类实例占用的资源
    void duqu();
    void cundang();

private slots: // 添加任务操作的槽函数声明
    void receiveData(QString zhuti,QString Neirong,int youxianji,QDate shijian,int xiugai,int finish);

    void on_m_addTaskButton_clicked();

    void on_m_removeTaskButton_clicked();

    void on_tableWidget_itemDoubleClicked(QTableWidgetItem *item);

    void on_comboBox_activated(int index);

    void ScreenInfo(int index);

    void on_m_addTaskButton_pressed();

    void on_m_removeTaskButton_pressed();

    void on_m_addTaskButton_released();

    void on_m_removeTaskButton_released();

private: // 私有成员函数和数据成员声明

    void deletework();

private:
    Ui::MainWindow *ui;//成员变量声明，指向一个由Qt Designer生成的用户界面类实例，用来管理UI文件中设计的界面元素
signals:
    void sendData2(QString,QString,int,QDate,int,int);
};
#endif // MAINWINDOW_H
//具体内容详见.cpp
