#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QtWidgets>
#include<QListWidgetItem>
#include<QDate>
#include<QTableWidgetItem>
#include<QCheckBox>
#include <QFile>
#include <QList>
#include <QString>
#include <QTextStream>
#include <QStringList>
MainWindow::MainWindow(QWidget *parent)//构造函数
    : QMainWindow(parent),ui(new Ui::MainWindow)
    {ui->setupUi(this);
        //以下是对界面进行美化
        this->setStyleSheet("background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 0, 0, 100), stop:0.7 rgba(123,104,238,100),stop:1 rgba(0, 255, 255, 100));"	);
        ui->tableWidget->setStyleSheet("background-color: rgb(245,255,250);" //背景颜色
                                       "border:1px solid rgb(0,255,255);border-radius:1px;");//边框粗细-颜色-圆角设置
        ui->m_addTaskButton->setStyleSheet("background-color: rgb(245,245,220);" //背景颜色
                                           "border:2px solid rgb(255,140,0);border-radius:2px;");//边框粗细-颜色-圆角设置
        ui->m_removeTaskButton->setStyleSheet("background-color: rgb(245,245,220);" //背景颜色
                                              "border:2px solid rgb(255,140,0);border-radius:2px;");//边框粗细-颜色-圆角设置
        ui->comboBox->setStyleSheet("font: 25 14pt '楷体';" //字体
                                    "color: rgb(31,31,31);"		//字体颜色
                                    "padding-left:20px;"       //内边距-字体缩进
                                    "background-color: rgb(245,245,220);" //背景颜色
                                    "border:2px solid rgb(255,127,80);border-radius:2px;");//边框粗细-颜色-圆角设置
        ui->textBrowser->setStyleSheet(
                                       "background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255,255,0, 150)stop:1 rgba(255,0, 255, 150));"		//字体颜色
                                       "padding-left:20px;"       //内边距-字体缩进
                                       "border:2px solid rgb(255,245,238);");//边框粗细-颜色-圆角设置
        //以下是创建tablewidget并设置标题栏
        ui->tableWidget->insertColumn(0);
        ui->tableWidget->insertColumn(1);
        ui->tableWidget->insertColumn(2);
        ui->tableWidget->insertColumn(3);
        ui->tableWidget->insertColumn(4);
        QComboBox *comboBox=new QComboBox();
        comboBox->addItem("截止日期");
        comboBox->addItem("今天");
        comboBox->addItem("近三天");
        comboBox->addItem("已过期");
        ui->tableWidget->setHorizontalHeaderItem(0,new QTableWidgetItem("截止日期"));
        ui->tableWidget->setHorizontalHeaderItem(1,new QTableWidgetItem("优先级"));
        ui->tableWidget->setHorizontalHeaderItem(2,new QTableWidgetItem("主题"));
        ui->tableWidget->setHorizontalHeaderItem(3,new QTableWidgetItem("内容"));
        ui->tableWidget->setHorizontalHeaderItem(4,new QTableWidgetItem("done"));
        ui->tableWidget->setColumnWidth(0,130);
        ui->tableWidget->setColumnWidth(1,50);
        ui->tableWidget->setColumnWidth(2,185);
        ui->tableWidget->setColumnWidth(3,290);
        ui->tableWidget->setColumnWidth(4,45);
        //这里实现了排序
        ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        //ui->tableWidget->setAlternatingRowColors(true);
        duqu();//读取文件内容
    }

MainWindow::~MainWindow()
{
    cundang();//存档
    delete ui;
}
void MainWindow::deletework(){
    ui->tableWidget->removeRow(ui->tableWidget->currentRow());
    //删除当前选中行
}


void MainWindow::on_m_addTaskButton_clicked(){//添加新窗口
    add *newwin=new add;
    //将子窗口信息传回主窗口
    connect(newwin,SIGNAL(sendData(QString,QString,int,QDate,int,int)),this,SLOT(receiveData(QString,QString,int,QDate,int,int)));
    //置于上层
    newwin->setWindowModality(Qt::ApplicationModal);
    newwin->show();
}
void MainWindow::receiveData(QString zhuti,QString Neirong,int youxianji,QDate shijian,int xiugai,int finish=0){
    //接收信息并进行更改//主题，内容，优先级，时间，是否修改，完成否
    ui->tableWidget->setSortingEnabled(false);
    if(xiugai!=-100){
        ui->tableWidget->removeRow(xiugai);
    }
    QString s=shijian.toString("yyyy/MM/dd");
    QString n=QString::number(youxianji);
    int rowCount=ui->tableWidget->rowCount();
    ui->tableWidget->insertRow(rowCount);
    if(zhuti.isEmpty()){
        zhuti="无";
    }
    if(Neirong.isEmpty()){
        Neirong="无";
    }
    ui->tableWidget->setItem(rowCount,0,new QTableWidgetItem(s));
    ui->tableWidget->setItem(rowCount,1,new QTableWidgetItem(n));
    ui->tableWidget->setItem(rowCount,2,new QTableWidgetItem(zhuti));
    ui->tableWidget->setItem(rowCount,3,new QTableWidgetItem(Neirong));
    ui->tableWidget->item(rowCount,0)->setTextAlignment(Qt::AlignCenter);
    ui->tableWidget->item(rowCount,1)->setTextAlignment(Qt::AlignCenter);
    ui->tableWidget->item(rowCount,2)->setTextAlignment(Qt::AlignCenter);
    //最右边的对钩按钮
    QTableWidgetItem *checkBox = new QTableWidgetItem();
    checkBox->setCheckState(Qt::Unchecked);
    if(finish)checkBox->setCheckState(Qt::Checked);
    ui->tableWidget ->setItem(rowCount, 4, checkBox);
    ui->tableWidget->setSortingEnabled(true);
    int index=ui->comboBox->currentIndex();
    ScreenInfo(index);//见下
}

void MainWindow::on_m_removeTaskButton_clicked()
{
    deletework();
}

void MainWindow::on_tableWidget_itemDoubleClicked(QTableWidgetItem *item)//双击进行修改
{
    int row=item->row();
    QString s=ui->tableWidget->item(row,0)->text();
    QString n=ui->tableWidget->item(row,1)->text();
    QString zhuti=ui->tableWidget->item(row,2)->text();
    QString neirong=ui->tableWidget->item(row,3)->text();
    int youxianji=n.toInt();
    QDate shijian=QDate::fromString(s,"yyyy/M/d");
    add *newwin=new add;
    int finished=ui->tableWidget->item(row,4)->checkState();
    //传信息
    connect(this,SIGNAL(sendData2(QString,QString,int,QDate,int,int)),newwin,SLOT(receiveData2(QString,QString,int,QDate,int,int)));
    sendData2(zhuti,neirong,youxianji,shijian,row,finished);
    connect(newwin,SIGNAL(sendData(QString,QString,int,QDate,int,int)),this,SLOT(receiveData(QString,QString,int,QDate,int,int)));
    newwin->setWindowModality(Qt::ApplicationModal);
    newwin->show();
}
void MainWindow::closeEvent(QCloseEvent *event){
    cundang();//关闭窗口存档
}
void MainWindow::duqu(){//读取文件内容
    QFile file("/data.txt");//"data/user.txt"为用户文件的路径
    file.open(QIODevice::ReadWrite | QIODevice::Text);//文件不存在会自动创建
    QString data;
    QStringList user_data;
    //判断文件是否打开成功
    if(file.isOpen())
    {
        if(file.size() != 0)//文件有数据
        {
            QTextStream in(&file);
            while(!in.atEnd())//一行一行一直读，直至读取失败
            {
                data=in.readLine();//读取一行存到data里
                user_data=data.split(" ");//将data里的数据以空格作为分隔符存到user_data
                QString zhuti=user_data.at(0);
                QString neirong=user_data.at(1);
                QString pri=user_data.at(2);
                QString date=user_data.at(3);
                QString ok=user_data.at(4);
                int finish=ok.toInt();
                int youxianji=pri.toInt();
                QDate shijian=QDate::fromString(date,"yyyy/M/d");
                this->receiveData(zhuti,neirong,youxianji,shijian,-100,finish);
                user_data.clear();//清空，便于存放下一行数据
            }
            file.close();
        }

    }
    else//文件打开失败
    {
        exit (0);
    }
}
void MainWindow::cundang(){//存档当前任务
    QFile file("/data.txt");
    file.open(QIODevice::WriteOnly| QIODevice::Text);//重刷文件，原文件数据被覆盖，重新写入一份
    if(file.isOpen())
    {
        QTextStream in(&file);
        int end=ui->tableWidget->rowCount();
        for(int row=0;row<end;row++){
            QString time=ui->tableWidget->item(row,0)->text();
            QString pri=ui->tableWidget->item(row,1)->text();
            QString zhuti=ui->tableWidget->item(row,2)->text();
            QString neirong=ui->tableWidget->item(row,3)->text();
            int ok=ui->tableWidget->item(row,4)->checkState();
            QString finish=QString::number(ok);
            in<<zhuti<<" "<<neirong<<" "<<pri<<" "<<time<<" "<<finish<<Qt::endl;
        }
        file.close();
    }
    else//文件打开失败
    {
        exit (0);
    }
}

void MainWindow::on_comboBox_activated(int index)//根据筛选器状态筛选
{
    ScreenInfo(index);
}
void MainWindow::ScreenInfo(int index){//筛选
    int rC = ui->tableWidget->rowCount();//获得行数
    if (index == 0) {//全部
        for (int i = 0; i < rC; i++) {
            ui->tableWidget->setRowHidden(i, false);//显示所有行
        }
    } else {
        QDate date=QDate::currentDate();
        //获取符合条件的cell索引
        QStringList  item;
        if(index==1){//今天
            for (int i = 0; i < rC; i++) {
                QString setdate=ui->tableWidget->item(i,0)->text();
                QDate shijian=QDate::fromString(setdate,"yyyy/M/d");
                int days=date.daysTo(shijian);
                if(days==0)item.append(QString::number(i));


            }
        }
        if(index==2){//三天内
            for (int i = 0; i < rC; i++) {
                QString setdate=ui->tableWidget->item(i,0)->text();
                QDate shijian=QDate::fromString(setdate,"yyyy/M/d");
                int days=date.daysTo(shijian);
                if(days>=0&&days<=3)item.append(QString::number(i));


            }
        }
        if(index==3){//过时
            for (int i = 0; i < rC; i++) {
                QString setdate=ui->tableWidget->item(i,0)->text();
                QDate shijian=QDate::fromString(setdate,"yyyy/M/d");
                int days=date.daysTo(shijian);
                if(days<0)item.append(QString::number(i));


            }
        }
        for (int i = 0; i < rC; i++) {
            ui->tableWidget->setRowHidden(i, true);//隐藏所有行
        }

        if (!item.isEmpty()) { //不为空
            for (int i = 0; i < item.count(); i++) {
                ui->tableWidget->setRowHidden(item.at(i).toInt(),false);//item.at(i).row()输出行号
            }
        }
    }

}
//以下四个是按按钮时变色的函数
void MainWindow::on_m_addTaskButton_pressed()
{
    ui->m_addTaskButton->setStyleSheet("background-color: rgba(	240,230,140,250);");
}


void MainWindow::on_m_removeTaskButton_pressed()
{
    ui->m_removeTaskButton->setStyleSheet("background-color: rgba(	240,230,140,250);");
}


void MainWindow::on_m_addTaskButton_released()
{
    ui->m_addTaskButton->setStyleSheet("background-color: rgb(245,245,220);"); //背景颜色
}


void MainWindow::on_m_removeTaskButton_released()
{
    ui->m_removeTaskButton->setStyleSheet("background-color: rgb(245,245,220);"); //背景颜色
}

